<!-- Datatables -->
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
{{--<script src="{{ asset('js/buttons.bootstrap4.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/buttons.colVis.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/buttons.html5.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/buttons.print.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/dataTables.bootstrap4.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/dataTables.buttons.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/dataTables.responsive.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/responsive.bootstrap4.min.js') }}"></script>--}}

